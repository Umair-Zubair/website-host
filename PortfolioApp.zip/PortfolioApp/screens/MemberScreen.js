import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";

export default function MemberScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Team Members</Text>

      <View style={styles.card}>
        <Text style={styles.name}>Your Name</Text>
        <Text style={styles.role}>Role: Home Page, Can Page, APIs & Database</Text>
        <Text style={styles.description}>
          Contributed to building the main homepage, integrating the can animation and dynamic updates from APIs.
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.name}>Partner Name</Text>
        <Text style={styles.role}>Role: Bottle Page & Spline Work</Text>
        <Text style={styles.description}>
          Developed the bottle page and implemented interactive 3D spline visuals for the website.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  card: {
    backgroundColor: "#f9f9f9",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  name: {
    fontSize: 18,
    fontWeight: "bold",
  },
  role: {
    fontSize: 16,
    marginVertical: 5,
  },
  description: {
    fontSize: 14,
  },
});
