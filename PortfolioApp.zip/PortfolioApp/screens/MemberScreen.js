// MemberScreen.js
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const ProfileCard = ({ name, onPress }) => {
  return (
    <Pressable style={styles.card} onPress={onPress}>
      <View style={styles.imageContainer}>
        {/* <Image source={require('./placeholder.png')} style={styles.image} /> */}
      </View>
      <Text style={styles.name}>{name}</Text>
    </Pressable>
  );
};

export default function MemberScreen() {
  const navigation = useNavigation();

  const teamMembers = [
    {
      name: 'Your Name',
      role: 'Role: Home Page, Can Page, APIs & Database',
      description: 'Contributed to building the main homepage, integrating the can animation and dynamic updates from APIs.',
    },
    {
      name: 'Partner Name',
      role: 'Role: Bottle Page & Spline Work',
      description: 'Developed the bottle page and implemented interactive 3D spline visuals for the website.',
    },
  ];

  const handleMemberSelect = (member) => {
    navigation.navigate('MemberDetails', { member });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Team Members</Text>
      <View style={styles.cardsContainer}>
        {teamMembers.map((member, index) => (
          <ProfileCard
            key={index}
            name={member.name}
            onPress={() => handleMemberSelect(member)}
          />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  cardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: '48%',
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    alignItems: 'center',
  },
  imageContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ccc',
    marginBottom: 10,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});