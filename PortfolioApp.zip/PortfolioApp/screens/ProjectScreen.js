import React from "react";
import { View, Text, StyleSheet, Button, Linking } from "react-native";
import * as Clipboard from "expo-clipboard";

const copyToClipboard = () => {
  Clipboard.setStringAsync("Surge Project - Interactive Web and Mobile Designs");
  alert("Project details copied to clipboard!");
};

<Button title="Copy Details to Clipboard" onPress={copyToClipboard} />

export default function ProjectScreen() {
  const openWebsite = () => {
    Linking.openURL("https://your-website-link.com"); // Replace with your actual link
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Project Details</Text>
      <Text style={styles.description}>
        Surge is a project showcasing interactive web and mobile designs. It includes animations,
        dynamic data, and a seamless user interface.
      </Text>
      <Button title="Visit Website" onPress={openWebsite} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f2f2f2",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "center",
  },
});

